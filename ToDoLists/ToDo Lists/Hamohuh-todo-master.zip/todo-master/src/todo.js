const Todo = (name, descrition, due, priority, isDone) => {
    return { name, descrition, due, priority, isDone }
}

export { Todo }


