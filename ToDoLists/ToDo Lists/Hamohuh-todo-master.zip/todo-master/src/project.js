//let projects = [];

const Project = (name) => {
    let todos = [];
    return { name, todos }
}

export { Project }
