ToDo simple webpage for The Odin Project practice.

using mainly vanilla JavaScript with Bootstrap & query help.

This project to practice (Webpack, Git, localStorage, and some more)

From The Odin Project's [curriculum](https://www.theodinproject.com/courses/javascript/lessons/todo-list). 

Live version can be found [here](https://hamohuh.github.io/todo)
