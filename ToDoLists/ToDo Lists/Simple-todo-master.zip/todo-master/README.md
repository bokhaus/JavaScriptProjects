# todo

continuing to practice npm, webpack and es6 modules by creating a to do app. 

more than one project can be created and different to dos can be added within.

[To Do App](https://0xtaf.github.io/todo/)
