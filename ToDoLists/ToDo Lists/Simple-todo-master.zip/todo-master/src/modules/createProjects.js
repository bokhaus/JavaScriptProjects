
const CreateProjects = (name) => {
   const todoArray = [];
   const priority = [];
   const isDone = [];
   return {name, todoArray, priority, isDone};
};

export default CreateProjects