/* CSS Stylesheets */
import './assets/css/normalize.css';
import './assets/css/style.css';

/* Images */

/* JS Modules */
import ToDoList from './modules/ToDoList/ToDoList';

ToDoList();
