import taskModule from './modules/tasks'
import projectModule from './modules/projects'
import domModule from './modules/domcontroller'
import eventModule from './modules/eventcontroller'

eventModule.init();

