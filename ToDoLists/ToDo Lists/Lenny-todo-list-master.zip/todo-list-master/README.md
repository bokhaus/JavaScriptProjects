# JustTodo
Minimalistic todo list app

[Preview](https://lenn-e.github.io/todo-list/)
